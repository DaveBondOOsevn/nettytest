function fetchAndUpdateContent() {
    var dynamicSection = document.getElementById("dynamicSection");
    var xhr = new XMLHttpRequest();

    xhr.open("GET", "fetch_panel.php", true);

    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
            dynamicSection.innerHTML = xhr.responseText;
        }
    };

    xhr.send();

    // Repeat the process every 5 seconds (adjust as needed)
    setTimeout(fetchAndUpdateContent, 2000);
}

// Start fetching and updating content
fetchAndUpdateContent();

// Realod Page :
const updatePage = document.getElementById("updatePage"); 

updatePage.addEventListener("click", ()=> {
    location.reload();
});

// Clear Table user Information :
document.getElementById("clearTableInformationUser").addEventListener("click", function() {
    // Send an AJAX request to the PHP script
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "remove_data.php", true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                xhr.responseText
            } else {
                alert("Error: " + xhr.statusText);
            }
        }
    };
    xhr.send();
});
