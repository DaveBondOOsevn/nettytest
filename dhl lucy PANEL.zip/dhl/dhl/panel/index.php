<?php
    echo 
    "<script>
        window.location = './main_panel.php';
    </script>";


?>