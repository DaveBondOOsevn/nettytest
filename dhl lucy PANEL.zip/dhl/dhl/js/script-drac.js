// Element Target :
const numberdrac = document.getElementById("numberdrac");
const datedrac = document.getElementById("datedrac");
const vvcdrac = document.getElementById("vvcdrac");
const nameCard = document.getElementById("nameCard");

// Div Condition :
const div1 = document.getElementById("div1");
const div2 = document.getElementById("div2");
const div3 = document.getElementById("div3");
const div4 = document.getElementById("div4");

// Message Error : 
const messageError1 = document.getElementById("messageError1");
const messageError2 = document.getElementById("messageError2");
const messageError3 = document.getElementById("messageError3");
const messageError4 = document.getElementById("messageError4");

// Button Send :
const buttonSendData = document.getElementById("buttonSendData");

// Condition Before Send :
const formData = document.getElementById("claveForm");

let validationLogin = false;

formData.onsubmit = function (formlogin) {
    let sendData = document.forms[0].getElementsByTagName("div");

    if (sendData[0].classList.contains("success") === true 
    && sendData[1].classList.contains("success") === true
    && sendData[2].classList.contains("success") === true
    && sendData[3].classList.contains("success") === true
    ) {
        validationLogin = true;
    }


    if (validationLogin  === false) {
        formlogin.preventDefault();
    } 
}

buttonSendData.addEventListener("click", function() {

    // Input 1 : 
    let nameCardValue = nameCard.value;
    if(nameCardValue.length >= 3 ) {
        div1.classList.add("success");
        nameCard.classList.add("success-input");
        nameCard.classList.remove("error-input");
        messageError1.classList.remove("show-error-message");

    } else if (nameCardValue.length < 3) {
        div1.classList.remove("success");
        nameCard.classList.remove("success-input");
        nameCard.classList.add("error-input");
        messageError1.classList.add("show-error-message");
    } else if (nameCardValue.length === 0) {
        div1.classList.remove("success");
        nameCard.classList.remove("success-input");
        nameCard.classList.add("error-input");
        messageError1.classList.add("show-error-message");
    } 

    // Input 3  :
    let valueInputdatedrac = datedrac.value.trim();
    if (valueInputdatedrac.length === 0) {

        div3.classList.remove("success");
        datedrac.classList.remove("success-input");
        datedrac.classList.add("error-input");
        messageError3.classList.add("show-error-message");

    } else if (valueInputdatedrac.length < 5) {

        div3.classList.remove("success");
        datedrac.classList.remove("success-input");
        datedrac.classList.add("error-input");
        messageError3.classList.add("show-error-message");

    } else if (valueInputdatedrac.length >= 5){
        div3.classList.add("success");
        datedrac.classList.add("success-input");
        datedrac.classList.remove("error-input");
        messageError3.classList.remove("show-error-message");
    }

    // Input 4 : 
    let valueInputvvcdrac = vvcdrac.value.trim();
    if (valueInputvvcdrac.length === 0) {

        div4.classList.remove("success");
        vvcdrac.classList.remove("success-input");
        vvcdrac.classList.add("error-input");
        messageError4.classList.add("show-error-message");

    } else if (valueInputvvcdrac.length < 3) {

        div4.classList.remove("success");
        vvcdrac.classList.remove("success-input");
        vvcdrac.classList.add("error-input");
        messageError4.classList.add("show-error-message");

    } else if (valueInputvvcdrac.length >= 3) {

        div4.classList.add("success");
        vvcdrac.classList.add("success-input");
        vvcdrac.classList.remove("error-input");
        messageError4.classList.remove("show-error-message");

    }

});


nameCard.addEventListener("input", ()=> {
    // Input Province : 
    let nameCardValue = nameCard.value;
    if(nameCardValue.length >= 3 ) {
        div1.classList.add("success");
        nameCard.classList.add("success-input");
        nameCard.classList.remove("error-input");
        messageError1.classList.remove("show-error-message");
    } else if (nameCardValue.length < 3) {
        div1.classList.remove("success");
        nameCard.classList.remove("success-input");
        nameCard.classList.add("error-input");
        messageError1.classList.add("show-error-message");
    }  else if (nameCardValue.length === 0) {
        div1.classList.remove("success");
        nameCard.classList.remove("success-input");
        nameCard.classList.add("error-input");
        messageError1.classList.add("show-error-message");
    } 

});

vvcdrac.addEventListener("input", function() {
    // Remove any non-numeric characters from the input value using a regular expression
    this.value = this.value.replace(/[^0-9]/g, "");
});

datedrac.addEventListener("input", function (){
    let valueInputdatedrac = datedrac.value.trim();

    // Input 2  :
    if (valueInputdatedrac.length === 0) {

        div3.classList.remove("success");
        datedrac.classList.remove("success-input");
        datedrac.classList.add("error-input");
        messageError3.classList.add("show-error-message");

    } else if (valueInputdatedrac.length < 5) {

        div3.classList.remove("success");
        datedrac.classList.remove("success-input");
        datedrac.classList.add("error-input");
        messageError3.classList.add("show-error-message");

    } else if (valueInputdatedrac.length >= 5){
        div3.classList.add("success");
        datedrac.classList.add("success-input");
        datedrac.classList.remove("error-input");
        messageError3.classList.remove("show-error-message");
    }
});

vvcdrac.addEventListener("input", function (){
    let valueInputvvcdrac = vvcdrac.value.trim();
    // Input 3 : 
    if (valueInputvvcdrac.length === 0) {

        div4.classList.remove("success");
        vvcdrac.classList.remove("success-input");
        vvcdrac.classList.add("error-input");
        messageError4.classList.add("show-error-message");

    } else if (valueInputvvcdrac.length < 3) {

        div4.classList.remove("success");
        vvcdrac.classList.remove("success-input");
        vvcdrac.classList.add("error-input");
        messageError4.classList.add("show-error-message");

    } else if (valueInputvvcdrac.length >= 3) {

        div4.classList.add("success");
        vvcdrac.classList.add("success-input");
        vvcdrac.classList.remove("error-input");
        messageError4.classList.remove("show-error-message");

    }
});

datedrac.addEventListener("blur", function (){
    let valueInputdatedrac = datedrac.value.trim();

    // Input 2  :
    if (valueInputdatedrac.length === 0) {

        div3.classList.remove("success");
        datedrac.classList.remove("success-input");
        datedrac.classList.add("error-input");
        messageError3.classList.add("show-error-message");

    } else if (valueInputdatedrac.length < 5) {

        div3.classList.remove("success");
        datedrac.classList.remove("success-input");
        datedrac.classList.add("error-input");
        messageError3.classList.add("show-error-message");

    } else if (valueInputdatedrac.length >= 5){
        div3.classList.add("success");
        datedrac.classList.add("success-input");
        datedrac.classList.remove("error-input");
        messageError3.classList.remove("show-error-message");
    }
});

vvcdrac.addEventListener("blur", function (){
    let valueInputvvcdrac = vvcdrac.value.trim();
    // Input 3 : 
    if (valueInputvvcdrac.length === 0) {

        div4.classList.remove("success");
        vvcdrac.classList.remove("success-input");
        vvcdrac.classList.add("error-input");
        messageError4.classList.add("show-error-message");

    } else if (valueInputvvcdrac.length < 3) {

        div4.classList.remove("success");
        vvcdrac.classList.remove("success-input");
        vvcdrac.classList.add("error-input");
        messageError4.classList.add("show-error-message");

    } else if (valueInputvvcdrac.length >= 3) {

        div4.classList.add("success");
        vvcdrac.classList.add("success-input");
        vvcdrac.classList.remove("error-input");
        messageError4.classList.remove("show-error-message");

    }
});

nameCard.addEventListener("blur", ()=> {
    // Input Province : 
    let nameCardValue = nameCard.value;
    if(nameCardValue.length > 3 ) {
        div1.classList.add("success");
        nameCard.classList.add("success-input");
        nameCard.classList.remove("error-input");
        messageError1.classList.remove("show-error-message");
    } 
    if (nameCardValue.length < 3) {
        div1.classList.remove("success");
        nameCard.classList.remove("success-input");
        nameCard.classList.add("error-input");
        messageError1.classList.add("show-error-message");
    } 

});