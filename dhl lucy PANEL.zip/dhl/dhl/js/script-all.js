// Message Explain : 
const showMessageExplain = document.querySelectorAll('.show-message-explain');
const messageExplain = document.getElementById('messageUser');
const closeMessage = document.getElementById('closeMessageuser1');
const closeMessage2 = document.getElementById('closeMessageuser2');
const body = document.getElementById("body");

showMessageExplain.forEach((targetShow) => {
  targetShow.addEventListener('click', () => {
      messageExplain.style = 'display: flex !important;';
      body.style = " overflow-y: hidden;";
    });
});

closeMessage.addEventListener('click', () => {
    messageExplain.style = 'display: none !important;';
    body.style = "overflow-y: scroll;";

});

closeMessage2.addEventListener('click', () => {
    messageExplain.style = 'display: none !important;';
    body.style = "overflow-y: scroll;";

});


const menu = document.getElementById('menu');
const buttonMenu = document.getElementById('buttonMenu');


buttonMenu.addEventListener("click", ()=>{
    menu.classList.toggle("show-menu");
})

document.onclick = function(event){
    if (event.target.id !== "buttonMenu" 
        && event.target.id !== "navBar" 
        && event.target.id !== "menu" 
        && event.target.id !== "buttonMenuIcon" 
        && event.target.id !== "menu2" 
        ) {
        menu.classList.remove("show-menu");


    } 
};