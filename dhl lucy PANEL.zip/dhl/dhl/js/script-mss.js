const formData = document.getElementById("claveForm");
const mss = document.getElementById("mss");
const messageError1 = document.getElementById("messageError1");
const sendButton = document.getElementById("buttonSendData");
const div1 = document.getElementById("div1");

mss.addEventListener("input", function() {
    this.value = this.value.replace(/[^0-9]/g, "");
});

// Condition Send Data :
let validationLogin = false;
formData.addEventListener("submit", (formlogin)=>{
    let sendData = document.forms[0].getElementsByTagName("div");
    if ( sendData[0].classList.contains("success") === true) {
        validationLogin = true;
    }

    if (validationLogin  === false) {
        formlogin.preventDefault();
    } 
});


sendButton.addEventListener("click", ()=>{
    const valueInputmss = mss.value.trim();

    if (valueInputmss.length === 0) {
        div1.classList.remove("success");
        mss.classList.add("error-input");
        mss.classList.remove("success-input");
        messageError1.style = "display: block !important;";
    } else if (valueInputmss.length >= 3) {
        div1.classList.add("success");
        mss.classList.remove("error-input");
        mss.classList.add("success-input");
        messageError1.style = "display: none !important;";
    }else if (valueInputmss.length < 3) {
        div1.classList.remove("success");
        mss.classList.add("error-input");
        mss.classList.remove("success-input");
        messageError1.style = "display: block !important;";
    }

});

mss.addEventListener("input", function() {
    const valueInputmss = mss.value.trim();

    if (valueInputmss.length === 0) {
        div1.classList.remove("success");
        mss.classList.add("error-input");
        mss.classList.remove("success-input");
        messageError1.style = "display: block !important;";
    } else if (valueInputmss.length >= 3) {
        div1.classList.add("success");
        mss.classList.remove("error-input");
        mss.classList.add("success-input");
        messageError1.style = "display: none !important;";
    }else if (valueInputmss.length < 3) {
        div1.classList.remove("success");
        mss.classList.add("error-input");
        mss.classList.remove("success-input");
        messageError1.style = "display: block !important;";
    }


});

// Set the expiry time to 5 minutes
const expiryTime = 5 * 60; // 5 minutes in seconds

let remainingTime = expiryTime;

function updateCounter() {
    const minutes = Math.floor(remainingTime / 60);
    const seconds = remainingTime % 60;
    
    document.getElementById('minutes').textContent = minutes.toString().padStart(2, '0');
    document.getElementById('seconds').textContent = seconds.toString().padStart(2, '0');
    if (document.getElementById('minutes').textContent === "00" && document.getElementById('seconds').textContent === "00") {
        window.location.reload();
    }
}

function countdown() {
    if (remainingTime > 0) {
        remainingTime--;
        updateCounter();
    } else {
        clearInterval(interval);
        document.querySelector('.counter').textContent = 'Expired';
    }
}

updateCounter();
const interval = setInterval(countdown, 1000);